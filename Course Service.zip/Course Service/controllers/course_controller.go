package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"

	"course-service/database"
	"course-service/models"
)

// Create Course
func CreateCourse(w http.ResponseWriter, r *http.Request) {

	var course models.Course

	err := json.NewDecoder(r.Body).Decode(&course)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := `
	INSERT INTO courses (course_name, duration, fee, seats)
	VALUES ($1, $2, $3, $4)
	`

	_, err = database.DB.Exec(
		r.Context(),
		query,
		course.CourseName,
		course.Duration,
		course.Fee,
		course.Seats,
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
	w.Write([]byte("Course Added Successfully"))
}

// Get All Courses
func GetCourses(w http.ResponseWriter, r *http.Request) {

	rows, err := database.DB.Query(
		r.Context(),
		"SELECT id, course_name, duration, fee, seats, created_at FROM courses",
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var courses []models.Course

	for rows.Next() {

		var course models.Course

		err := rows.Scan(
			&course.ID,
			&course.CourseName,
			&course.Duration,
			&course.Fee,
			&course.Seats,
			&course.CreatedAt,
		)

		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		courses = append(courses, course)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(courses)
}

// Get Course By ID
func GetCourseByID(w http.ResponseWriter, r *http.Request) {

	params := mux.Vars(r)
	id := params["id"]

	var course models.Course

	query := `
	SELECT id, course_name, duration, fee, seats, created_at
	FROM courses
	WHERE id=$1
	`

	err := database.DB.QueryRow(
		r.Context(),
		query,
		id,
	).Scan(
		&course.ID,
		&course.CourseName,
		&course.Duration,
		&course.Fee,
		&course.Seats,
		&course.CreatedAt,
	)

	if err != nil {
		http.Error(w, "Course Not Found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(course)
}

// Update Course
func UpdateCourse(w http.ResponseWriter, r *http.Request) {

	params := mux.Vars(r)
	id := params["id"]

	var course models.Course

	err := json.NewDecoder(r.Body).Decode(&course)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := `
	UPDATE courses
	SET course_name=$1,
		duration=$2,
		fee=$3,
		seats=$4
	WHERE id=$5
	`

	_, err = database.DB.Exec(
		r.Context(),
		query,
		course.CourseName,
		course.Duration,
		course.Fee,
		course.Seats,
		id,
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write([]byte("Course Updated Successfully"))
}

// Delete Course
func DeleteCourse(w http.ResponseWriter, r *http.Request) {

	params := mux.Vars(r)
	id := params["id"]

	query := `DELETE FROM courses WHERE id=$1`

	_, err := database.DB.Exec(
		r.Context(),
		query,
		id,
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write([]byte("Course Deleted Successfully"))
}