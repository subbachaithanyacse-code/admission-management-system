package models

import "time"

type Course struct {
	ID         int       `json:"id"`
	CourseName string    `json:"course_name"`
	Duration   string    `json:"duration"`
	Fee        float64   `json:"fee"`
	Seats      int       `json:"seats"`
	CreatedAt  time.Time `json:"created_at"`
}