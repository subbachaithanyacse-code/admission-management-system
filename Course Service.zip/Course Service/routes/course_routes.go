package routes

import (
	"github.com/gorilla/mux"

	"course-service/controllers"
)

func RegisterCourseRoutes(router *mux.Router) {

	router.HandleFunc("/courses", controllers.CreateCourse).Methods("POST")

	router.HandleFunc("/courses", controllers.GetCourses).Methods("GET")

	router.HandleFunc("/courses/{id}", controllers.GetCourseByID).Methods("GET")

	router.HandleFunc("/courses/{id}", controllers.UpdateCourse).Methods("PUT")

	router.HandleFunc("/courses/{id}", controllers.DeleteCourse).Methods("DELETE")
}