package main

import (
	"fmt"
	"net/http"

	"github.com/gorilla/mux"

	"course-service/database"
	"course-service/routes"
)

func Home(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Welcome to Course Service")
}

func main() {

	database.ConnectDB()

	router := mux.NewRouter()

	router.HandleFunc("/", Home).Methods("GET")

	routes.RegisterCourseRoutes(router)

	fmt.Println("Course Service Started on Port 8085")

	err := http.ListenAndServe(":8085", router)
	if err != nil {
		fmt.Println(err)
	}
}