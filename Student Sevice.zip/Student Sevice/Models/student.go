package Models

import "time"

type Student struct {
	ID        int       `json:"id"`
	FullName  string    `json:"fullname"`
	Email     string    `json:"email"`
	Phone     string    `json:"phone"`
	Course    string    `json:"course"`
	CreatedAt time.Time `json:"created_at"`
}