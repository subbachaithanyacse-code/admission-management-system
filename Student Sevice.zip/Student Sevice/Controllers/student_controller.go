package Controllers

import (
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"

	"student-service/Database"
	"student-service/Models"
)

// Create Student
func CreateStudent(w http.ResponseWriter, r *http.Request) {

	var student Models.Student

	err := json.NewDecoder(r.Body).Decode(&student)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := `
	INSERT INTO students (fullname, email, phone, course)
	VALUES ($1, $2, $3, $4)
	`

	_, err = Database.DB.Exec(
		r.Context(),
		query,
		student.FullName,
		student.Email,
		student.Phone,
		student.Course,
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
	w.Write([]byte("Student Added Successfully"))
}

// Get All Students
func GetStudents(w http.ResponseWriter, r *http.Request) {

	rows, err := Database.DB.Query(
		r.Context(),
		"SELECT id, fullname, email, phone, course, created_at FROM students",
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var students []Models.Student

	for rows.Next() {

		var student Models.Student

		err := rows.Scan(
			&student.ID,
			&student.FullName,
			&student.Email,
			&student.Phone,
			&student.Course,
			&student.CreatedAt,
		)

		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		students = append(students, student)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(students)
}

// Get Student By ID
func GetStudentByID(w http.ResponseWriter, r *http.Request) {

	params := mux.Vars(r)
	id := params["id"]

	var student Models.Student

	query := `
	SELECT id, fullname, email, phone, course, created_at
	FROM students
	WHERE id=$1
	`

	err := Database.DB.QueryRow(
		r.Context(),
		query,
		id,
	).Scan(
		&student.ID,
		&student.FullName,
		&student.Email,
		&student.Phone,
		&student.Course,
		&student.CreatedAt,
	)

	if err != nil {
		http.Error(w, "Student Not Found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(student)
}

// Update Student
func UpdateStudent(w http.ResponseWriter, r *http.Request) {

	params := mux.Vars(r)
	id := params["id"]

	var student Models.Student

	err := json.NewDecoder(r.Body).Decode(&student)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	query := `
	UPDATE students
	SET fullname=$1,
		email=$2,
		phone=$3,
		course=$4
	WHERE id=$5
	`

	_, err = Database.DB.Exec(
		r.Context(),
		query,
		student.FullName,
		student.Email,
		student.Phone,
		student.Course,
		id,
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write([]byte("Student Updated Successfully"))
}

// Delete Student
func DeleteStudent(w http.ResponseWriter, r *http.Request) {

	params := mux.Vars(r)
	id := params["id"]

	query := `
	DELETE FROM students
	WHERE id=$1
	`

	_, err := Database.DB.Exec(
		r.Context(),
		query,
		id,
	)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write([]byte("Student Deleted Successfully"))
}