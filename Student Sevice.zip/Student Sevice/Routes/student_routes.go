package Routes

import (
	"github.com/gorilla/mux"

	"student-service/Controllers"
)

func RegisterStudentRoutes(router *mux.Router) {

	// Home
	router.HandleFunc("/students", Controllers.CreateStudent).Methods("POST")

	// Get All Students
	router.HandleFunc("/students", Controllers.GetStudents).Methods("GET")

	// Get Student By ID
	router.HandleFunc("/students/{id}", Controllers.GetStudentByID).Methods("GET")
}