package main

import (
	"fmt"
	"net/http"

	"github.com/gorilla/mux"

	"student-service/Database"
	"student-service/Routes"
)

func Home(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Welcome to Admission Management System")
}

func main() {

	Database.ConnectDB()

	router := mux.NewRouter()

	router.HandleFunc("/", Home).Methods("GET")

	// Register Student Routes
	Routes.RegisterStudentRoutes(router)

	fmt.Println("Server started on Port 8083")

	err := http.ListenAndServe(":8083", router)
	if err != nil {
		fmt.Println(err)
	}
}